package com.anhanguera.projeto.core;

import org.springframework.stereotype.Service;

import com.anhanguera.projeto.model.PessoaFisica;
import com.anhanguera.projeto.model.PessoaJuridica;

@Service
public class PessoaCore {

	// pessoa fisica
	public PessoaFisica salvarPessoaFisica(PessoaFisica pessoa) {
		pessoa.validarInformacoes();
		System.out.println("Salvar a pessoa no banco de dados : " + pessoa.toString());
		return pessoa;
	}

	// pessoa juridica
	public PessoaJuridica salvarPessoaJuridica(PessoaJuridica pessoa) {
		pessoa.validarInformacoes();
		System.out.println("Salvar a pessoa no banco de dados : " + pessoa.toString());
		return pessoa;
	}

	
}
