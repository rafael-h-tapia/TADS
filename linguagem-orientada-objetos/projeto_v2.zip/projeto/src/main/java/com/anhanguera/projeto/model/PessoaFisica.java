package com.anhanguera.projeto.model;

import java.time.LocalDate;

import org.apache.logging.log4j.util.Strings;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class PessoaFisica extends Pessoa {

	private String cpf;
	private LocalDate dataDeNascimento;

	@Override
	public void validarInformacoes() {

		// dataDeNascimento (entre 1 e 200)
		int anoAtual = LocalDate.now().getYear();
		int anoNasc = dataDeNascimento.getYear();
		int idade = anoAtual - anoNasc;
		if (idade <= 0 || idade > 200) {
			System.out.println("Data de nascimento inválida: " + dataDeNascimento);
		}

		// valida se o cpf foi preenchido
		if (Strings.isBlank(cpf)) {
			System.out.println("CPF é obrigatório!");
		}
	}
}
