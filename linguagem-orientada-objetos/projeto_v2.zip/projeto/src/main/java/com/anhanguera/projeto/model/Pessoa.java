package com.anhanguera.projeto.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class Pessoa {

	private String nome;
	private String telefone;
	private String email;

	// Método abstrato para validar informações específicas
	public abstract void validarInformacoes();

}
