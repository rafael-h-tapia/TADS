package com.anhanguera.projeto.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class PessoaJuridica extends Pessoa{
	
	private String cnpj;
	private String razaoSocial;
	
	@Override
	public void validarInformacoes() {
		if (cnpj == null) {
			System.out.println("CNPJ é obrigatório!");
		}
		if (cnpj == "") {
			System.out.println("CNPJ é obrigatório!");
		}
	}
}
