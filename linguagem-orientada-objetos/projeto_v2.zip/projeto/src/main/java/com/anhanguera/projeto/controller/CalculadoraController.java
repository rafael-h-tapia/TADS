package com.anhanguera.projeto.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anhanguera.projeto.core.CalculadoraCore;

@RestController
@RequestMapping("/calculadora")
public class CalculadoraController {

	private final CalculadoraCore calculadoraCore = new CalculadoraCore();

	// Endpoint para somar
	@GetMapping("/somar")
	public double somar(@RequestParam double numero1, @RequestParam double numero2) {
		return calculadoraCore.somar(numero1, numero2);
	}

	// Endpoint para subtrair
	@GetMapping("/subtrair")
	public double subtrair(@RequestParam double numero1, @RequestParam double numero2) {
		return calculadoraCore.subtrair(numero1, numero2);
	}

	// Endpoint para multiplicar
	@GetMapping("/multiplicar")
	public double multiplicar(@RequestParam double numero1, @RequestParam double numero2) {
		return calculadoraCore.multiplicar(numero1, numero2);
	}

	// Endpoint para dividir
	@GetMapping("/dividir")
	public double dividir(@RequestParam double numero1, @RequestParam double numero2) {
		return calculadoraCore.dividir(numero1, numero2);
	}

}
