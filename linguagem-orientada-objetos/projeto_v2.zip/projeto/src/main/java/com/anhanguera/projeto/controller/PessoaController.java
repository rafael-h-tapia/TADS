package com.anhanguera.projeto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anhanguera.projeto.core.PessoaCore;
import com.anhanguera.projeto.model.PessoaFisica;
import com.anhanguera.projeto.model.PessoaJuridica;

@RestController
@RequestMapping("/pessoa")
public class PessoaController {

	@Autowired
	private PessoaCore pessoaCore;

	@PostMapping("/pessoa-fisica/criar")
	public PessoaFisica criarPessoaFisica(
			@RequestBody PessoaFisica pessoa) {
		return pessoaCore.salvarPessoaFisica(pessoa);
	}

	@PostMapping("/pessoa-juridica/criar")
	public PessoaJuridica criarPessoaJuridica(
			@RequestBody PessoaJuridica pessoa) {
		return pessoaCore.salvarPessoaJuridica(pessoa);
	}

}
