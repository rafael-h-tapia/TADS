package com.anhanguera.projeto.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {

	@Id
	public Integer id;

	@Column(name = "nome")
	public String nome;

	@Column(name = "email")
	public String email;

	@Column(name = "telefone")
	public String telefone;

}