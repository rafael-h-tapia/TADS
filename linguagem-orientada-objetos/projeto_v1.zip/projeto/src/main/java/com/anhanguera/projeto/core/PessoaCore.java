package com.anhanguera.projeto.core;

import org.springframework.stereotype.Service;

import com.anhanguera.projeto.model.Pessoa;

@Service
public class PessoaCore {

	public Pessoa salvarPessoa(Pessoa pessoa) {
		System.out.println("Salvar a pessoa no banco de dados : " + pessoa.toString());
		return pessoa;
	}

}
