package com.anhanguera.projeto.core;

public class CalculadoraCore {

	// Método de adição
	public double somar(double a, double b) {
		return a + b;
	}

	// Método de subtração
	public double subtrair(double a, double b) {
		return a - b;
	}

	// Método de multiplicação
	public double multiplicar(double a, double b) {
		return a * b;
	}

	// Método de divisão
	public double dividir(double a, double b) {
		if (b == 0) {
			throw new IllegalArgumentException("Divisão por zero não é permitida.");
		}
		return a / b;
	}

}
