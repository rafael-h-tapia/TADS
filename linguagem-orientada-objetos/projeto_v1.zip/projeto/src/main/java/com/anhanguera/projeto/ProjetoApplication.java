package com.anhanguera.projeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoApplication.class, args);

		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("SWAGGER INICIADO EM:");
		System.out.println("http://localhost:8080/swagger-ui/index.html");
		System.out.println("-----------------------------------------------------------------------------");
	}

}
