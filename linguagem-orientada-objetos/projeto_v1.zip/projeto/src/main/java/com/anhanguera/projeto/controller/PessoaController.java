package com.anhanguera.projeto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anhanguera.projeto.core.PessoaCore;
import com.anhanguera.projeto.model.Pessoa;

@RestController
@RequestMapping("/pessoa")
public class PessoaController {

	@Autowired
	private PessoaCore pessoaCore;

	// Endpoint para criar uma nova pessoa
	@PostMapping("/criar")
	public Pessoa criarPessoa(@RequestBody Pessoa pessoa) {
		return pessoaCore.salvarPessoa(pessoa);
	}

}
